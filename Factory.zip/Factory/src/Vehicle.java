public interface Vehicle {
    public void changeTires();
}
