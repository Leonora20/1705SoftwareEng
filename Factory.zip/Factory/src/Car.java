public class Car implements Vehicle{

    @Override
    public void changeTires() {
        System.out.println("Changed 4 tires of Car");
    }
}
